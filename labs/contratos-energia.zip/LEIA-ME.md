# Laboratório de energia: começar aqui

Extraia o ZIP inteiro em uma pasta. Abra terminal nesta raiz, que contém labs/ e MANIFEST.json.
É necessário um Python 3 já disponível. Sem dependências externas; nenhuma instalação é executada.
Verificado no Mac com CPython 3.14.5; execução em Windows e outras versões ainda pendente.

Comando de referência no Mac:

    python3 -m labs.contratos-energia.environment
    python3 -m labs.contratos-energia.environment --verify
    python3 -m unittest discover -s labs/contratos-energia -t .
    python3 -m labs.contratos-energia.pipeline labs/contratos-energia/measurements.json

No Windows, use python ou py -3 no lugar de python3, conforme o executável configurado.
Resultados de referência: energias [24.0,400.0,0.0] J. Confira valores e testes, sem exigir texto de ambiente igual.
BUILD_ENVIRONMENT.json registra o ambiente observado na construção; não comprova execução no dispositivo de destino.

MANIFEST.json lista SHA-256 dos arquivos incluídos, exceto ele mesmo. --verify confere esses arquivos;
não audita arquivos extras nem é assinatura de autoria ou prova de correção científica.
Não copie um ambiente .venv de um sistema para outro; recrie-o localmente se precisar de isolamento.
Este laboratório não necessita criar .venv, instalar pacotes ou mudar configurações.

Mais hipóteses e limites em labs/contratos-energia/README.md. Material próprio assistido por IA em rascunho para revisão.
