"""Laboratórios didáticos originais."""
